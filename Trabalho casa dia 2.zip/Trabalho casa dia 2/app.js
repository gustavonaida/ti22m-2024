function ano(idade){
    if (5 <= idade && idade <= 7) {

        console.log('A')
        
    } else {

        if (idade >= 8 && idade <= 10) {

            console.log("B")
            
        } else {
            
        }
        
    }
}