function compensaAlcool(precoAlcool, precoGasolina) {
    return precoAlcool < (precoGasolina * 0.7);
   }