function reverseString(str) {
    return str.split('').reverse().join('');
}

console.log(reverseString("javascript"));
console.log(reverseString("hello"));