function printDescending(n) {
    for (let i = n; i >= 1; i--) {
    console.log(i);
    }
   }