function printEvenDescending(n) {
    for (let i = n; i >= 1; i--) {
    if (i % 2 === 0) {
    console.log(i);
    }
    }
   }