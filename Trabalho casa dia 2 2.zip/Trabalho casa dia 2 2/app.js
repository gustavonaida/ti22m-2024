function printAscending(n) {
    for (let i = 1; i <= n; i++) {
    console.log(i);
    }
   }